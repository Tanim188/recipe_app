class BackgroundImages {
  BackgroundImages._();

  static const String homepageBackgroundImage =
      "assets/images/background/homepageBackground.jpeg";
}
