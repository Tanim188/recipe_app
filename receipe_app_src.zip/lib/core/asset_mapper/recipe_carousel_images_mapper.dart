class AppImages {
  AppImages._();

  static const String image1 =
      "assets/images/carosual_images/receipe_image_1.jpg";
  static const String image2 =
      "assets/images/carosual_images/receipe_image_2.jpg";
  static const String image3 =
      "assets/images/carosual_images/receipe_image_3.jpg";
  static const String image4 =
      "assets/images/carosual_images/receipe_image_4.jpg";
  static const String image5 =
      "assets/images/carosual_images/receipe_image_5.jpg";
}

// HomepageCarouselImages
final List<String> homepageCarouselImages = [
  AppImages.image1,
  AppImages.image2,
  AppImages.image3,
  AppImages.image4,
  AppImages.image5
];

// final List<String> imagesPath = [
//       "assets/images/carosual_images/receipe_image_1.jpg",
//       "assets/images/carosual_images/receipe_image_2.jpg",
//       "assets/images/carosual_images/receipe_image_3.jpg",
//       "assets/images/carosual_images/receipe_image_4.jpg",
//       "assets/images/carosual_images/receipe_image_5.jpg",
//     ];
