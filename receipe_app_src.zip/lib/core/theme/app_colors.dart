import 'dart:ui';

class AppColor {
  AppColor();

  static const Color primaryColor = Color(0xFF1B365D);

  // static const Color primaryColor = Color(0xFF183155);
  static const Color onPrimaryColor = Color(0xFFFFFFFF);
  static const Color secondaryColor = Color(0xFFCDECE9);
  static const Color onSecondaryColor = Color(0xFF58595B);
}
