class RecipeRouteName {
  RecipeRouteName._();

  static const String authenticationPage = "/authenticationPage";
  static const String homepage = "/homepage";
}
