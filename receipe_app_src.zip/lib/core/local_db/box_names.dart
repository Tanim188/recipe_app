class HiveBoxName {
  static const String signupBox = "signup_box";
  static const String foodRecipeStoreBox = "food_recipe_store_box";
  static const String sessionStatePersistentStoreBox =
      "session_state_persistent_store_box";
}
