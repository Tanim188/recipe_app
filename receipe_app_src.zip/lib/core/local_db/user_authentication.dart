class UserAuthentication {
  // create user account
  // login the user
  // logout the user
}
